create database grizzlystore;
use grizzlystore;
create table product(
           product_id int not null ,
           product_name varchar(255),
           product_brand varchar(255),
           product_category varchar(255),
           product_rating varchar(255),
           product_price varchar(255),
           primary key(product_id)
           );
           
           insert into product values (1,'Trimmer','philips','personal care','4.7','43.3');
           insert into product values (2,'Shaver','Braun','personal care','4.5','89.3');
                                   
           select * from product;
create table login(
           username varchar(255),
           password varchar(255),
           role varchar(255),
           attempts varchar(255) ,
           primary key(username)
           );


insert into login values('John','abc','Admin','active');
insert into login values('Harini','abcd','Admin','active');
insert into login values('Hima','abc','Admin','active');
insert into login values('Kowsalya','abcd','Admin','active');
insert into login values('Booja','abcde','Admin','active');
insert into login values('sara','abc','Vendor','active');
insert into login values('diana','abcd','Vendor','active');
select * from login;


create table inventory(
			product_id int,
		    inventory_buffer int,
            inventory_instock int,
       
            FOREIGN KEY (product_id) REFERENCES product(product_id) on delete cascade);
insert into inventory values(1,30,15);
insert into inventory values(2,45,32);
            
select * from inventory;

drop table login;
drop table product;
drop table inventory;

            
