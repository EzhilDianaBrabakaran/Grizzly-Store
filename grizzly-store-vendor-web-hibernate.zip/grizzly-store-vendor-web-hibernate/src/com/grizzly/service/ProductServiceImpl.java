package com.grizzly.service;

import java.util.ArrayList;
import com.grizzly.dao.*;

import com.grizzly.pojo.GrizzlyPojo;

public class ProductServiceImpl implements ProductService {

	ProductDao product= new ProductDaoImpl();
	@Override
	public ArrayList inventoryFetch() throws ApplicationException {
		// TODO Auto-generated method stub
		ArrayList arrayList=product.inventoryFetch();
		return arrayList;
	}

	@Override
	public void removeProduct(int id) throws ApplicationException {
		// TODO Auto-generated method stub
		product.removeProduct(id);

	}

	@Override
	public void add(GrizzlyPojo gPojo) throws ApplicationException {
		
		product.add(gPojo);

	}

	@Override
	public void update(GrizzlyPojo gPojo) throws ApplicationException {
		
		product.update(gPojo);

	}

}
