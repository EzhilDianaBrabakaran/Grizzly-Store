package com.grizzly.service;

import com.grizzly.dao.ApplicationException;
import com.grizzly.pojo.LoginPojo;

public interface LoginService {
	void  loginLock(LoginPojo lPojo) throws ApplicationException;
	LoginPojo checkUser(LoginPojo lPojo) throws ApplicationException;
	

}
