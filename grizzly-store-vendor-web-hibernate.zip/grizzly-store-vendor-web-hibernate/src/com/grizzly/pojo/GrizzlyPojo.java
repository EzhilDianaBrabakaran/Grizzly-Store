package com.grizzly.pojo;

public class GrizzlyPojo {
	private int productId;
	private String productName;
	private String productBrand;
	private String productCategory;
	private String productRating;
	private String productPrice;
	
	private int inventoryBuffer;
	private int inventoryInstock;
	private int inventoryRequired;
	
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public int getInventoryRequired() {
		return inventoryRequired;
	}
	public void setInventoryRequired(int inventoryRequired) {
		this.inventoryRequired = inventoryRequired;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductRating() {
		return productRating;
	}
	public void setProductRating(String productRating) {
		this.productRating = productRating;
	}
	public int getInventoryBuffer() {
		return inventoryBuffer;
	}
	public void setInventoryBuffer(int inventoryBuffer) {
		this.inventoryBuffer = inventoryBuffer;
	}
	public int getInventoryInstock() {
		return inventoryInstock;
	}
	public void setInventoryInstock(int inventoryInstock) {
		this.inventoryInstock = inventoryInstock;
	}

}
