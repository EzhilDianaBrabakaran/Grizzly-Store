package com.grizzly.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.grizzly.dao.ApplicationException;
import com.grizzly.service.ProductService;
import com.grizzly.service.ProductServiceImpl;

/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	public static Logger logger = Logger.getLogger("Grizzly-store-hibernate");
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int check=1;
		ProductService product8= new ProductServiceImpl();
		String idNumber=request.getParameter("sId");
		int id=Integer.parseInt(idNumber);
	    try {
			product8.removeProduct(id);
			System.out.println(id);
		    System.out.println(check);
			if(check==1)
			{
			ProductService product4= new ProductServiceImpl();
			ArrayList allProducts=product4.inventoryFetch();
			
			request.setAttribute("allProducts", allProducts);
			
		    RequestDispatcher rd=request.getRequestDispatcher("FetchProduct.jsp");
			rd.forward(request, response);
			}
			else
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("Error.jsp");
				dispatcher.forward(request, response);
			}

		} 
	    catch (ApplicationException e) 
	    {
			logger.error(e);
		}
	    		
	}

}
